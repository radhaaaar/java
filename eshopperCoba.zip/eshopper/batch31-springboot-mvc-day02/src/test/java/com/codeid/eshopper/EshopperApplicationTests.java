package com.codeid.eshopper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EshopperApplicationTests {

	@Test
	void contextLoads() {
	}

}
