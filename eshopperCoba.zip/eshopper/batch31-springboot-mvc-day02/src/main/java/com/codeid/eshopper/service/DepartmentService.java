package com.codeid.eshopper.service;

import java.util.List;

import com.codeid.eshopper.entities.Department;

public interface DepartmentService {
    List<Department> findAllDepartment();   
}
